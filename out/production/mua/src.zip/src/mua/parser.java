package mua;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import mua.Utils;

public class parser {
    Scanner sc;
    public NameSpace variables;
    public parser(Scanner sc, NameSpace variables) {
        this.sc = sc;
        this.variables = variables;
    }

    public Data parse() {
        Operator.Variables = variables;
        String str = sc.next();

        if (str.charAt(0) == '[') {
            str = Utils.getList(str, sc, "[", "]");
           // System.out.println(str);
            return new Data(str);
        } else if (str.charAt(0) == '(') {
            str = Utils.getList(str, sc, "(", ")");
            Expression exp = new Expression(str, variables);
           // System.out.println(str);
            return exp.parse();
        }
        //System.out.println(str);
        if (str.charAt(0) == ':') {
            Operator op = Operator.thing;
            Data name = new Data(str.substring(1));
            Data[] args = {name};
            return op.execute(args);
        }
        Data res = null;
        Data v = new Data(str);
        if (v.isOperator()) {
            Operator op = Operator.valueOf(v.toString());

            int cnt = op.getOperand();
            Data[] args = null;
            if (cnt > 0) {
                args = new Data[cnt];
                for (int i = 0; i < cnt; i++)
                    args[i] = parse();
            }
            res = op.execute(args);
            if (v.toString() == "RETURN") {
                while (sc.hasNext()) sc.next();
            }
        }
        else if (!v.isWord() && variables.getValue(v.getValue()) != null && variables.getValue(v.getValue()).isFunction()) {
            Operator op = Operator.function;
            int cnt = Utils.getOperand(v.getValue());
            Data[] args = new Data[cnt + 1];
            args[0] = new Data(v.getValue());
            for (int i = 1; i <= cnt; i++) args[i] = parse();
//            System.out.print(v.getValue());
//            for (int i = 1; i <= cnt; i++) System.out.print(args[i].toString() + " ");
//            System.out.println("");
//            if (args[1].toString().equals("0.0")) {
//                System.out.println("fuck");
//            }

            res = Operator.function.execute(args);
        }
        else res = v;
        return res;
    }
}

class Expression {
    String str;
    NameSpace var;
    char ch;
    int pos, len;
    char[] c;
    Expression(String str, NameSpace var){
        this.str = str.trim();
        this.var = var;
        if (str.startsWith("(")) this.str = str.substring(1, str.length() - 1);
        c = this.str.toCharArray();
        len = this.str.length();
        pos = -1;
        nextpos();
    }
    Data[] wrapup(Data...x) {
        List<Data> res = new ArrayList<Data>(Arrays.asList(x));
        Data[] ret = new Data[res.size()];
        res.toArray(ret);
        return ret;
    }
    Data parse() {
        Data x = parseNumber();
        for (;;) {
            if (check('+'))
                x = Operator.add.execute(wrapup(x, parseNumber()));
            else if (check('-')) x = Operator.sub.execute(wrapup(x, parseNumber()));
            else return x;
        }
    }

    Data parseNumber() {
        Data x = parseFactor();
        for (;;) {
            if (check('*')) {
                int y = 0;
                x = Operator.mul.execute(wrapup(x, parseFactor()));
            }
            else if (check('/')) x = Operator.div.execute(wrapup(x, parseFactor()));
            else if (check('%')) x = Operator.mod.execute(wrapup(x, parseFactor()));
            else return x;
        }
    }

    Data parseFactor() {
        if (check('-')) {
            Data res = parseFactor();
            return new Data(String.valueOf(res.neg()));
        }
        if (check('+')) return parseFactor();
        Data x;
        if (check('(')) {
            int sum = 1, left = pos, right = 0;
            for (; pos < len; pos ++) {
                if (c[pos] == '(')  {
                    sum ++;
                }
                else if (c[pos] == ')') {
                    sum --;
                    if (sum == 0) {
                        right = pos;
                        break;
                    }
                }
            }
            nextpos();
            x = (new Expression(str.substring(left, right), var)).parse();
        }
        else if (ch >= '0' && ch <= '9') {
            int num = 0;
            for ( ; ch >= '0' && ch <= '9' && pos + 1 <= len; nextpos()) num = num * 10 + ch - '0';
           x = new Data(String.valueOf(num));
        }
        else if (ch == ':') {
            String var = "";
            for ( nextpos(); !Utils.oper.contains(ch) && ch != ' ' && pos + 1 <= len; nextpos()) var = var + ch;
            x = Operator.thing.execute(wrapup(new Data(var)));
        }
        else {
            Scanner newsc = new Scanner(str.substring(pos));
            x = (new parser(newsc, var)).parse();
        }
        return x;

    }
    void nextpos() {
        pos ++;
        if (pos < len) ch = c[pos];
        else ch = '$';
    }
    boolean check(char x) {
        while (ch == ' ') nextpos();
        if (ch == x) {
            nextpos();
            return true;
        }
        return false;
    }
}
