package mua;

import java.util.Scanner;

public enum Operator {

    make(2) {
        public Data execute(Data[] args) {
            Variables.insert(args[0].getValue(), args[1]);
            return null;
        }
    },
    print(1) {
        public Data execute(Data[] args) {
            System.out.println(args[0].getValue());
            return args[0];
        }
    },
    thing(1) {
        public Data execute(Data[] args) {
            Data res = Variables.getValue(args[0].getValue());
            return res;
        }
    },
    read(0) {
        public Data execute(Data[] args) {
//            Scanner sc = new Scanner(Main.stdin);
            String str = Main.sc.next();
            Data res = new Data(str);
            return res;
            
        }
    },
    add(2) {
        public Data execute(Data[] args) {
            double sum = args[0].toNumber() + args[1].toNumber();
            Data res = new Data(String.valueOf(sum));
            return res;
        }
    },
    sub(2) {
        public Data execute(Data[] args) {
            double sum = args[0].toNumber() - args[1].toNumber();
            Data res = new Data(String.valueOf(sum));
            return res;
        }
    },
    mul(2) {
        public Data execute(Data[] args) {
            double sum = args[0].toNumber() * args[1].toNumber();
            Data res = new Data(String.valueOf(sum));
            return res;
        }
    },
    div(2) {
        public Data execute(Data[] args) {
            double sum = args[0].toNumber() / args[1].toNumber();
            Data res = new Data(String.valueOf(sum));
            return res;
        }
    },
    mod(2) {
        public Data execute(Data[] args) {
            int sum = (int) (args[0].toNumber()) % (int)(args[1].toNumber());
            Data res = new Data(String.valueOf(sum));
            return res;
        }
    }, 
    and(2) {
        public Data execute(Data[] args) {
            boolean res = (args[0].toBool()) & (args[1].toBool());
            if (res) return new Data("true");
            else return new Data("false");
        }
    },
    or(2) {
        public Data execute(Data[] args) {
            boolean res = (args[0].toBool()) | (args[1].toBool());
            if (res) return new Data("true");
            else return new Data("false");
        }
    },
    not(1) {
        public Data execute(Data[] args) {
            if (args[0].not()) return new Data("true");
            else return new Data("false");
        }
    },
    gt(2) {
        public Data execute(Data[] args) {
            if (args[0].compareTo(args[1]) == 1) return new Data("true");
            else return new Data("false");
        }
    },
    lt(2) {
        public Data execute(Data[] args) {
            if (args[0].compareTo(args[1]) == -1) return new Data("true");
            else return new Data("false");
        }
    },
    eq(2) {
        public Data execute(Data[] args) {
//            System.out.println(args[0].toString());
//            System.out.println(args[1].toString());
            if (args[0].compareTo(args[1]) == 0) return new Data("true");
            else return new Data("false");
        }
    }, 
    islist(1){
        public Data execute(Data[] args) {
            if (args[0].isList()) return new Data("true");
            else return new Data("false");
        }
    },
    isbool(1){
        public Data execute(Data[] args) {
            if (args[0].isBool()) return new Data("true");
            else return new Data("false");
        }
    },
    isnumber(1) {
        public Data execute(Data[] args) {
            if (args[0].isNumber()) return new Data("true");
            else return new Data("false");
        } 
    },
    isword(1) {
        public Data execute(Data[] args) {
            if (args[0].isWord()) return new Data("true");
            else return new Data("false");
        } 
    },
    isname(1) {
        public Data execute(Data[] args) {
            String str = args[0].getValue();
            if (Variables.getValue(str) != null) return new Data("true");
            else return new Data("false");
        }  
    },
    isempty(1) {
        public Data execute(Data[]  args) {
            if (args[0].isEmpty()) return new Data("true");
            else return new Data("false");
        }
    },
    erase(1) {
        public Data execute(Data[] args) {
            String str = args[0].getValue();
            Data res = Variables.getValue(str);
            Variables.erase(str);
            return res;
        } 
    },
    IF(3) {
        public Data execute(Data[] args) {
            Data[] param = new Data[1];
            if (args[0].toBool()) param[0] = args[1];
            else param[0] = args[2];
            return run.execute(param);
        } 
    },
    run(1) {
        public Data execute(Data[] args) {
            parser newp = new parser(args[0].getValue().trim());
            Data res = newp.parse();
            while (true) {
                Data temp = newp.parse();
                if (temp == null) break;
                else res = temp;
            }
            return res;
        } 
    };


    int Operand;
    Operator(int Operand) {this.Operand = Operand;}
    Operator() {}



    public int getOperand() {
        return Operand;
    }
    abstract Data execute(Data[]  args);
    public static NameSpace Variables = new NameSpace();
}
