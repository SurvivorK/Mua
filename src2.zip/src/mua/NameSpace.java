package mua;

import java.util.HashMap;

public class NameSpace {
    public HashMap<String, Data> var = new HashMap<>();
    NameSpace() {
        var.clear();
    }

    public boolean hasName(String name) {
        if (var.containsKey(name)) return true;
            else return false;
    }
    public void insert(String name, Data val) {
        var.put(name, val);
       // check();
    }
    public void erase(String name) {
        var.remove(name);
    }
    public Data getValue(String name) {
        //check();
        if (hasName(name)) return var.get(name);
        else return null;
        
    }
    public void check() {
        for (HashMap.Entry<String, Data> entry : var.entrySet()) {
            System.out.println("key = " + entry.getKey() + ", value = " + entry.getValue());
        }
    }
}  
