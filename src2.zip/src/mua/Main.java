package mua;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Main {
    
    public static InputStream stdin = System.in;
    public static Scanner sc = new Scanner(stdin);
    public static void main(String [] args) {
        
//        try {
//            File file = new File("./in");
//            InputStream fin = new FileInputStream(file);
//            System.setIn(fin);
//            Scanner sc = new Scanner(fin);
//            System.setIn(stdin);
//            Scanner sc = new Scanner(stdin);
            while (true) {
                if (!sc.hasNext()) break;
                String inst = sc.nextLine();
//                if (inst.equals("print (2*(-2+6)/4)")) {
//                    System.out.println("fuck");
//                }
//                System.out.println(inst);
                if (inst.equals("")) continue;
                parser p = new parser(inst);
                p.parse();
            }
//            fin.close();
//        } catch(FileNotFoundException e) {
//            e.printStackTrace();
//        }catch (IOException e) {
//
//        }
    }
}