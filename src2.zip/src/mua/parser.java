package mua;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class parser {
    char ch;
    public int pos, len;
    char[] c;
    List<Character> oper = Arrays.asList('+', '-', '*', '/', '(',')');
    parser(String str) {
        c = str.toCharArray();
        len = str.length();
        pos = -1;
        nextPos();
    }

    void nextPos() {
        pos++;
        if (pos < len) ch = c[pos];
        else ch = ' ';
    }

    boolean check(char x) {
        while (ch == ' ') nextPos();
        if (ch == x) {
            nextPos();
            return true;
        }
        return false;
    }

    String nextWord() {
        String res = "";
        while (ch == ' ' && pos < len) nextPos();
        // whether ch is the beginning of a expression or lists
        boolean flag = false;
        if (ch == '(' || ch == '[') flag = true;
        // if not, it shouldn't contain any operator symbol
        while (ch != ' ' && ((!flag & !oper.contains(ch)) || flag) && pos < len) {
            res = res + ch;
            nextPos();
        }
        return res;
    }

    public Data parse() {
        String str = nextWord();
        if (str == "") return null;
        if (str.charAt(0) == '[') {
            int tot = 0;
            for (int i = 0; i < str.length(); i++)
                if (str.charAt(i) == '[') tot++;
                else if (str.charAt(i) == ']') tot--;
            while (true) {
                str = str + ch;
                if (ch == '[') tot++;
                else if (ch == ']') tot--;
                nextPos();
                if (tot == 0 || pos >= len) break;
            }
        } else if (str.charAt(0) == '(') {
            int tot = 0;
            for (int i = 0; i < str.length(); i++)
                if (str.charAt(i) == '(') tot++;
                else if (str.charAt(i) == ')') tot--;
            while (true) {
                str = str + ch;
                if (ch == '(') tot++;
                else if (ch == ')') tot--;
                nextPos();
                if (tot == 0 || pos >= len) break;
            }
            Expression exp = new Expression(str);
            return exp.parse();
        }
        if (str.charAt(0) == ':') {
            Operator op = Operator.thing;
            Data name = new Data(str.substring(1));
            Data[] args = {name};
            return op.execute(args);
        }
        Data res = null;
        Data v = new Data(str);
        if (v.isOperator()) {
            Operator op = Operator.valueOf(v.toString());

            int cnt = op.getOperand();
            Data[] args = null;
            if (cnt > 0) {
                args = new Data[cnt];
                for (int i = 0; i < cnt; i++)
                    args[i] = parse();
            }
            res = op.execute(args);
        } else res = v;
        return res;
    }
}

 class Expression {
     String str;
     char ch;
     int pos, len;
     char[] c;
     Expression(String str){
         this.str = str;
         c = str.toCharArray();
         len = str.length();
         pos = -1;
         nextpos();
     }
     Data[] wrapup(Data...x) {
         List<Data> res = new ArrayList<Data>(Arrays.asList(x));
         Data[] ret = new Data[res.size()];
         res.toArray(ret);
         return ret;
     }
     Data parse() {
         Data x = parseNumber();
         for (;;) {
             if (check('+'))
                 x = Operator.add.execute(wrapup(x, parseNumber()));
             else if (check('-')) x = Operator.sub.execute(wrapup(x, parseNumber()));
             else return x;
         }
     }

     Data parseNumber() {
         Data x = parseFactor();
         for (;;) {
             if (check('*')) {
                 int y = 0;
                 x = Operator.mul.execute(wrapup(x, parseFactor()));
             }
             else if (check('/')) x = Operator.div.execute(wrapup(x, parseFactor()));
             else if (check('%')) x = Operator.mod.execute(wrapup(x, parseFactor()));
             else return x;
         }
     }

     Data parseFactor() {
         if (check('-')) {
             Data res = parseFactor();
             return new Data(String.valueOf(res.neg()));
         }
         if (check('+')) return parseFactor();
         Data x;
         if (check('(')) {
             x = parse();
             check(')');
         }
         else if (ch >= '0' && ch <= '9') {
             int num = 0;
             for ( ; ch >= '0' && ch <= '9' && pos + 1 <= len; nextpos()) num = num * 10 + ch - '0';
            x = new Data(String.valueOf(num));
         }
         else {
            parser p = new parser(str.substring(pos));
            x = p.parse();
            pos = pos + p.pos;
            ch = c[pos];
         }
         return x;

     }
     void nextpos() {
         pos ++;
         if (pos < len) ch = c[pos];
         else ch = '$';
     }
     boolean check(char x) {
         while (ch == ' ') nextpos();
         if (ch == x) {
             nextpos();
             return true;
         }
         return false;
     }
  }
